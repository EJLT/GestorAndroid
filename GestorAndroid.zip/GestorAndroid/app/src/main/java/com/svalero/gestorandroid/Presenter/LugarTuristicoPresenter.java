// LugarTuristicoPresenter.java
package com.svalero.gestorandroid.Presenter;


public interface LugarTuristicoPresenter {
    void listarLugares();
    void mostrarFormularioAgregar();
    void mostrarFormularioActualizar();
    void mostrarConfirmacionEliminar();
}
