package com.svalero.gestorandroid.Presenter;


public interface RestaurantePresenter {
    void listarRestaurantes();
    void mostrarFormularioAgregar();
    void mostrarFormularioActualizar();
    void mostrarConfirmacionEliminar();
}
