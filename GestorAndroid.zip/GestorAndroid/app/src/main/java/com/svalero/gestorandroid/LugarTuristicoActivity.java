package com.svalero.gestorandroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.gestorandroid.R;
import com.svalero.gestorandroid.Implements.LugarTuristicoPresenterImpl;
import com.svalero.gestorandroid.LugaresTuristicos.ActualizarLugarActivity;
import com.svalero.gestorandroid.LugaresTuristicos.AgregarLugarActivity;
import com.svalero.gestorandroid.LugaresTuristicos.BorrarLugarActivity;
import com.svalero.gestorandroid.LugaresTuristicos.ListarLugarActivity;
import com.svalero.gestorandroid.Model.LugarTuristicoModel;
import com.svalero.gestorandroid.Presenter.LugarTuristicoPresenter;
import com.svalero.gestorandroid.View.LugarTuristicoView;

import java.util.List;


public class LugarTuristicoActivity extends AppCompatActivity implements LugarTuristicoView {

    private Button btnListarLugares;
    private Button btnAgregarLugarTuristico;
    private Button btnActualizarLugarTuristico;
    private Button btnEliminarLugarTuristico;

    private LugarTuristicoPresenter lugarTuristicoPresenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lugar_turistico);

        btnListarLugares = findViewById(R.id.btnListarLugares);
        btnAgregarLugarTuristico = findViewById(R.id.btnAgregarLugarTuristico);
        btnActualizarLugarTuristico = findViewById(R.id.btnActualizarLugarTuristico);
        btnEliminarLugarTuristico = findViewById(R.id.btnEliminarLugarTuristico);

        // Inicializar el presentador y pasar la vista actual (this)
        lugarTuristicoPresenter = new LugarTuristicoPresenterImpl(this);

        // Configurar clics de botones
        btnListarLugares.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LugarTuristicoActivity.this, ListarLugarActivity.class));
            }
        });

        btnAgregarLugarTuristico.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LugarTuristicoActivity.this, AgregarLugarActivity.class));
            }
        });

        btnActualizarLugarTuristico.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LugarTuristicoActivity.this, ActualizarLugarActivity.class));
            }
        });

        btnEliminarLugarTuristico.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LugarTuristicoActivity.this, BorrarLugarActivity.class));
            }
        });
    }

    @Override
    public void mostrarLugares(List<LugarTuristicoModel> lugares) {
        // Implementa la lógica para mostrar la lista de lugares
        showToast("Listar lugares");
    }

    @Override
    public void mostrarFormularioAgregar() {
        showToast("Mostrar formulario agregar");
    }

    @Override
    public void mostrarFormularioActualizar() {
        showToast("Mostrar formulario actualizar");
    }

    @Override
    public void mostrarConfirmacionEliminar() {
        showToast("Mostrar confirmación eliminar");
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
